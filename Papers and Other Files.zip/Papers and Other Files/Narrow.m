clc
clear
%% Normalized Amplitude

[tones1, Fs1] = audioread('A4.wav'); % Audio Signal 1   

N1 = length(tones1);
t1 = (0:N1-1)/Fs1; % time axis from signal amplitude
NM1 = normalize(tones1,'range') % Normalized signal amplitude

subplot(3,1,1)

plot(1000*t1,NM1)
xlabel('Time (ms)')
%xlim([0 10000]);
ylabel('Amplitude')
title('Normalized Signal 1')
%% Narrow Plot
Max_Y = max(tones1); %Find Max Y value
X = (t1(Max_Y==tones1)); % Find X value for Max Y value
X_inx = find(tones1==Max_Y); %Find the indexed x value for max Y value

% y axis
new_vec = NM1(X_inx-178:1:X_inx+178); %indexed vector from max amplitude of original  signal
new_vec = detrend(new_vec); % Remove max amplitude at 0 Hz
fft_nvec = fft(new_vec); % fft of .004 interval from max amplitude of original signal
fft_nvec_abs = abs(fft_nvec);
fft_nvec_norm = normalize(fft_nvec_abs,'range');


% x axis
tindex_nvec = 0:1:length(new_vec)-1 ;%indexed, for 4ms from max amplitude
t_act = tindex_nvec/Fs1 ;%indexed vector to actual time vector

subplot(3,1,2)
plot(t_act*1000,fft_nvec_norm)
xlabel('Time (ms)')
ylabel('Amplitude')
title('FFT near Max Amplitude')

%% 

N2 = length(fft_nvec);
t1 = (0:N2-1)*Fs1;


P2 = abs(fft_nvec/N2)
P1 = P2(1:N2/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f1 = Fs1*(0:(N2/2))/N2;
p_norm = normalize(P1,'range')
subplot(3,1,3)
plot(f1,p_norm) 
title('Single-Sided Amplitude Spectrum of X(t)')
xlim([1000 10000]);
xlabel('f (Hz)')
ylabel('|P1(f)|')

for q = 1:length(p_norm)
    if p_norm(q) > .8
       x_norm(q) = 1
    else x_norm(q) = 0
    end
end 
x_norm = transpose(x_norm)
    

% Max_Y = max(X_mags(1000:10000))
% X =(fax_Hz(X_mags==Max_Y))
% X = X(1)
% 
% yint = X_mags(1000:10000);
% ysum = sum(yint)
