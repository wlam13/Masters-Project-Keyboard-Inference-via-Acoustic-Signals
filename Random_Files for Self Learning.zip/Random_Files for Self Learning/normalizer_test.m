[tones1, Fs1] = audioread('A1.wav');

N1 = numel(tones1);
t1 = (0:N1-1)/Fs1; 
 
subplot(2,2,1)

plot(1e3*t1,tones1)
xlabel('Time (ms)')
%xlim([0 10000]);
ylabel('Amplitude')
title('DTMF Signal A')
subplot(2,2,2)

pspectrum(tones1,Fs1,'FrequencyLimits',[4000 10000])
f11 = [meanfreq(tones1,Fs1,[4000 10000])]


tones1 = detrend(tones1)
data_fft1 = fft(tones1);

subplot(2,2,3)
plot(abs(data_fft1(:,1)))
xlabel('Frequency')
ylabel('Amplitude')
title('FFT of Signal 1')

%% 

% Normalize Energy of Keyboard Input
NM1 = normalize(tones1,'range')
subplot(2,2,4)
plot(t1,NM1)
xlabel('Frequency')
ylabel('Amplitude')
title('Normalized Energy')