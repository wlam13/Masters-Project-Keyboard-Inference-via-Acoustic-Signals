clc
clear
%% Normalized Amplitude

[tones1, Fs1] = audioread('A1.wav'); % Audio Signal 1   

N1 = length(tones1);
t1 = (0:N1-1)/Fs1; % time axis from signal amplitude
NM1 = normalize(tones1,'range') % Normalized signal amplitude

subplot(2,1,1)

plot(1000*t1,NM1)
xlabel('Time (ms)')
%xlim([0 10000]);
ylabel('Amplitude')
title('Normalized Signal 1')
%% Narrow Plot
Max_Y = max(tones1); %Find Max Y value
X = (t1(Max_Y==tones1)); % Find X value for Max Y value
X_inx = find(tones1==Max_Y); %Find the indexed x value for max Y value

% y axis
new_vec = NM1(X_inx-10:1:X_inx+10); %indexed vector from max amplitude of original  signal
new_vec = detrend(new_vec); % Remove max amplitude at 0 Hz
fft_nvec = fft(new_vec); % fft of at max amplitude of original signal
fft_nvec_abs = abs(fft_nvec);
fft_nvec_norm = normalize(fft_nvec_abs,'range');


% x axis
tindex_nvec = 0:1:length(new_vec)-1 ;%indexed, for 4ms from max amplitude
t_act = tindex_nvec/Fs1 ;%indexed vector to actual time vector

subplot(2,1,2)
plot(t_act*1000,fft_nvec_norm)
xlabel('Time (ms)')
ylabel('Amplitude')
title('FFT near Max Amplitude')