[tones1, Fs1] = audioread('A1.wav');

tones1 = detrend(tones1)
data_fft1 = fft(tones1);

subplot(3,1,1)
plot(abs(data_fft1(:,1)))
xlabel('Frequency')
ylabel('Amplitude')


[tones2, Fs2] = audioread('A2.wav');
data_fft2 = fft(tones2);

subplot(3,1,2)
plot(abs(data_fft2(:,1)))
xlabel('Frequency');
ylabel('Amplitude');

[tones3, Fs3] = audioread('A3.wav');
data_fft3 = fft(tones3);

subplot(3,1,3)
plot(abs(data_fft3(:,1)))
xlabel('Frequency');
ylabel('Amplitude');