[tones1, Fs1] = audioread('A1.wav');
[tones2, Fs2] = audioread('A2.wav');
[tones3, Fs3] = audioread('A3.wav');

N1 = numel(tones1);
t1 = (0:N1-1)/Fs1; 

subplot(3,3,1)

plot(1e3*t1,tones1)
xlabel('Time (ms)')
%xlim([0 10000]);
ylabel('Amplitude')
title('Normalized Signal A')
subplot(3,3,2)

pspectrum(tones1,Fs1,'FrequencyLimits',[4000 10000])
f11 = [meanfreq(tones1,Fs1,[4000 10000])]


tones1 = detrend(tones1)
data_fft1 = fft(tones1);

subplot(3,3,3)
plot(abs(data_fft1(:,1)))
xlabel('Frequency')
ylabel('Amplitude')
title('FFT of Signal 1')


%%
N2 = numel(tones2);
t2 = (0:N2-1)/Fs2; 

subplot(3,3,4)

plot(1e3*t2,tones2)
xlabel('Time (ms)')
%xlim([0 10000]);
ylabel('Amplitude')
title('Normalized Signal B')
subplot(3,3,5)

pspectrum(tones2,Fs2,'FrequencyLimits',[4000 10000])
f12 = [meanfreq(tones2,Fs2,[4000 10000])]

data_fft2 = fft(tones2);

subplot(3,3,6)
plot(abs(data_fft2(:,1)))
xlabel('Frequency');
ylabel('Amplitude');
title('FFT of Signal 2')


%%

N3 = numel(tones3);
t3 = (0:N3-1)/Fs3; 



subplot(3,3,7)

plot(1e3*t3,tones3)
xlabel('Time (ms)')
%xlim([0 10000]);
ylabel('Amplitude')
title('Normalized Signal C')
subplot(3,3,8)

pspectrum(tones3,Fs3,'FrequencyLimits',[4000 10000])
f13 = [meanfreq(tones3,Fs3,[4000 5000])]

data_fft3 = fft(tones3);

subplot(3,3,9)
plot(abs(data_fft3(:,1)))
xlabel('Frequency');
ylabel('Amplitude');
title('FFT of Signal 3');