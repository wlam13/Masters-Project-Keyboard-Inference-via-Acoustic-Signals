clc
clear
format long g

[tones1, Fs1] = audioread('A1.wav');



N = length(tones1)
tones1 = tones1 - mean(tones1);
X_mags = abs(fft(tones1));
X_mags = normalize(X_mags,'range');
bin_vals = [0 : N-1];
fax_Hz = bin_vals*Fs1/N;
N_2 = ceil(N/2);


plot(fax_Hz(1:N_2),X_mags(1:N_2));
xlim([1000 10000]);
xlabel('Frequency (Hz)')
ylabel('Magnitude')

Max_Y = max(X_mags(1000:10000))
X =(fax_Hz(X_mags==Max_Y))
X = X(1)

yint = X_mags(1000:10000);
ysum = sum(yint)
