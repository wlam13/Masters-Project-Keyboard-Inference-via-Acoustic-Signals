
[tones1, Fs1] = audioread('A1.wav');
[tones2, Fs2] = audioread('A2.wav');
[tones3, Fs3] = audioread('A3.wav');

N1 = numel(tones1);
t1 = (0:N1-1)/Fs1; 
NM1 = normalize(tones1,'range')

subplot(3,3,1)

plot(1e3*t1,NM1)
xlabel('Time (ms)')
%xlim([0 10000]);
ylabel('Amplitude')
title('Normalized Signal A')


pspectrum(tones1,Fs1,'FrequencyLimits',[4000 10000])
f11 = [meanfreq(tones1,Fs1,[4000 10000])]
subplot(3,3,2)

tones1 = detrend(tones1)
data_fft1 = fft(tones1);

subplot(3,3,3)
plot(abs(data_fft1(:,1)))
xlabel('Frequency')
ylabel('Amplitude')
title('FFT of Signal 1')


%%
N2 = numel(tones2);
t2 = (0:N2-1)/Fs2; 
NM2 = normalize(tones2,'range')

subplot(3,3,4)

plot(1e3*t2,NM2)
xlabel('Time (ms)')
%xlim([0 10000]);
ylabel('Amplitude')
title('Normalized Signal B')
subplot(3,3,5)

pspectrum(tones2,Fs2,'FrequencyLimits',[4000 10000])
f12 = [meanfreq(tones2,Fs2,[4000 10000])]

data_fft2 = fft(tones2);

subplot(3,3,6)
plot(abs(data_fft2(:,1)))
xlabel('Frequency');
ylabel('Amplitude');
title('FFT of Signal 2')


%%

N3 = numel(tones3);
t3 = (0:N3-1)/Fs3; 
NM3 = normalize(tones3,'range')


subplot(3,3,7)

plot(1e3*t3,NM3)
xlabel('Time (ms)')
%xlim([0 10000]);
ylabel('Amplitude')
title('Normalized Signal C')
subplot(3,3,8)

pspectrum(tones3,Fs3,'FrequencyLimits',[4000 10000])
f13 = [meanfreq(tones3,Fs3,[4000 5000])]

data_fft3 = fft(tones3);

subplot(3,3,9)
plot(abs(data_fft3(:,1)))
xlabel('Frequency');
ylabel('Amplitude');
title('FFT of Signal 3');

Favg = (f11 + f12 + f13)/3
% f = [meanfreq(tones,Fs,[700 800]), ...
%      meanfreq(tones,Fs,[800 900]), ...
%      meanfreq(tones,Fs,[900 1000]), ...
%      meanfreq(tones,Fs,[1300 1400])];

%pspectrum(tones,Fs,'spectrogram','Leakage',1,'OverlapPercent',0, ...
   % 'MinThreshold',-10,'FrequencyLimits',[650, 1500]);