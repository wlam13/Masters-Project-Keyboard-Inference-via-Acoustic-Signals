[tones1, Fs1] = audioread('A1.wav');
[tones2, Fs2] = audioread('A4.wav')
[tones3, Fs3] = audioread('A5.wav');

NM1 = normalize(tones1,'range')
NM2 = normalize(tones2,'range')
NM3 = normalize(tones3,'range')

[r lags] = xcorr(tones1,tones2);
[r2 lags2] = xcorr(tones1,tones3);
[r3 lags3] = xcorr(tones2,tones3);

RM1 = normalize(r,'range')
RM2 = normalize(r2,'range')
RM3 = normalize(r3,'range')

[x1, i1] = max(RM1)
[x2, i2] = max(RM2)
[x3, i3] = max(RM3)

t12 = lags(i1)
t13 = lags(i2)
t23 = lags(i3)

subplot(3,1,1)
plot(lags,RM1)

subplot(3,1,2)
plot(lags2,RM2)

subplot(3,1,3)
plot(lags3,RM3)
