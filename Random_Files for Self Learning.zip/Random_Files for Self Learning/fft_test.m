%% Set of FFT Spectrum of AudioFile of Keyboard Input
% Frequency spectrum of interest lies between 1000-10000 Hz

clc
clear

[tones1, Fs1] = audioread('A2.wav');

N1 = numel(tones1);
T = 1/Fs1;
L = length(tones1)
t1 = (0:N1-1)*Fs1; 

Y = fft(tones1);
P2 = abs(Y/L)
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f1 = Fs1*(0:(L/2))/L;
p_norm = normalize(P1,'range')

plot(f1,p_norm) 
title('Single-Sided Amplitude Spectrum of X(t)')
xlim([1000 10000]);
xlabel('f (Hz)')
ylabel('|P1(f)|')


