clc
clear
%% Input Audio Data

[tones1, Fs1] = audioread('A1.wav'); % Audio Signal 1   
[tones2, Fs2] = audioread('A2.wav'); % Audio Signal 2

%% Normalized Magnitude Spectrum of Audio Signal 1
N1 = numel(tones1);
t1 = (0:N1-1)/Fs1; 
NM1 = normalize(tones1,'range')

subplot(2,2,1)

plot(1e3*t1,NM1)
xlabel('Time (ms)')
%xlim([0 10000]);
ylabel('Amplitude')
title('Normalized Signal 1')

%% Normalized Magnitude Spectrum of Audio Signal 2
N2 = numel(tones2);
t2 = (0:N2-1)/Fs2; 
NM2 = normalize(tones2,'range')

subplot(2,2,3)

plot(1e3*t2,NM2)
xlabel('Time (ms)')
%xlim([0 10000]);
ylabel('Amplitude')
title('Normalized Signal 2')
%% Xcorr of Audio Signal 1 and 2
% [r lags] = xcorr(tones1,tones2);
% RM1 = normalize(r,'range')
% [x1, i1] = max(RM1)
% t12 = lags(i1)
% subplot(3,1,2)
% plot(lags/1000,RM1)
% title('Xcorr between Signal 1 and 2')
% xlabel('f (Hz)')
% ylabel('Magnitude')

%% FFT, Single Sided Spectrum of Audio Signal 1

N1 = numel(tones1);
T = 1/Fs1;
L1 = length(tones1)

Y = fft(tones1);
A1 = abs(Y/L1)
B1 = A1(1:L1/2+1);
B1(2:end-1) = 2*B1(2:end-1);
f1 = Fs1*(0:(L1/2))/L1;
p_norm = normalize(B1,'range')


subplot(2,2,2)
plot(f1,p_norm) 
title('Normalized Single-Sided Amplitude Spectrum of Signal 1')
xlim([1000 10000]);
%xlim([0 1000]);
xlabel('f (Hz)')
ylabel('Magnitude')

%% FFT, Single Sided Spectrum of Audio Signal 2
N2 = numel(tones2);
T = 1/Fs2;
L2 = length(tones2)

Y2 = fft(tones2);
A2 = abs(Y2/L2)
B2 = A2(1:L2/2+1);
B2(2:end-1) = 2*B2(2:end-1);
f2 = Fs2*(0:(L2/2))/L2;
p_norm2 = normalize(B2,'range')


subplot(2,2,4)
plot(f2,p_norm2) 
title('Normalized Single-Sided Amplitude Spectrum of Signal 2')
xlim([1000 10000]);
%xlim([0 1000]);
xlabel('f (Hz)')
ylabel('Magnitude')

