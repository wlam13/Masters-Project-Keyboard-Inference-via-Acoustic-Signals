
[tones1, Fs1] = audioread('A1.wav')
[tones2, Fs2] = audioread('A2.wav')
[tones3, Fs3] = audioread('A3.wav')

N1 = numel(tones1);
t1 = (0:N1-1)/Fs1; 
title('A')
subplot(3,2,1)

plot(1e3*t1,tones1)
xlabel('Time (ms)')
%xlim([0 10000]);
ylabel('Amplitude')
title('DTMF Signal A')
subplot(3,2,2)

pspectrum(tones1,Fs1,'spectrogram','FrequencyLimits',[0 45000])

%%
N2 = numel(tones2);
t2 = (0:N2-1)/Fs2; 
subplot(3,2,3)

plot(1e3*t2,tones2)
xlabel('Time (ms)')
%xlim([0 10000]);
ylabel('Amplitude')
title('DTMF Signal B')
subplot(3,2,4)

pspectrum(tones2,Fs2,'spectrogram','FrequencyLimits',[0 45000])
%%

N3 = numel(tones3);
t3 = (0:N3-1)/Fs3; 
subplot(3,2,5)

plot(1e3*t3,tones3)
xlabel('Time (ms)')
%xlim([0 10000]);
ylabel('Amplitude')
title('DTMF Signal C')
subplot(3,2,6)

pspectrum(tones3,Fs3,'spectrogram','FrequencyLimits',[0 45000])
% f = [meanfreq(tones,Fs,[700 800]), ...
%      meanfreq(tones,Fs,[800 900]), ...
%      meanfreq(tones,Fs,[900 1000]), ...
%      meanfreq(tones,Fs,[1300 1400])];
% round(f)




%pspectrum(tones,Fs,'spectrogram','Leakage',1,'OverlapPercent',0, ...
   % 'MinThreshold',-10,'FrequencyLimits',[650, 1500]);